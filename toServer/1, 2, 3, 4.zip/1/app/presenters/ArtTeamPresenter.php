<?php

namespace App\Presenters;

use Nette,
	App\Model;


/**
 * ArtTeam presenter.
 */
class ArtTeamPresenter extends BasePresenter{
    
}
