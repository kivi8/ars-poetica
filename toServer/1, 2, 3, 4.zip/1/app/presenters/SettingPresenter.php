<?php

namespace App\Presenters;

use Nette,
	App\Model;


/**
 * Setting presenter.
 */
class SettingPresenter extends BasePresenter{
    
}
