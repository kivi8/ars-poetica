<?php

namespace App\AdminModule\Presenters;

use Nette;

class CommentsPresenter extends BasePresenter{
    
    
}
