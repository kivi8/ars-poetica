<?php

namespace App\AdminModule\Presenters;

use Nette;

class HomepagePresenter extends BasePresenter{
    
    
}
