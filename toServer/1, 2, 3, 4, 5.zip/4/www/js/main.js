$(function () {
                $.nette.init();
            });