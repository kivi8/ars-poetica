<?php

namespace App\Presenters;

use Nette,
	App\Model;


/**
 * SendArticle presenter.
 */
class SendArticlePresenter extends BasePresenter{
    
}
