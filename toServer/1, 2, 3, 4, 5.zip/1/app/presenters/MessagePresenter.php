<?php

namespace App\Presenters;

use Nette,
	App\Model;


/**
 * Message presenter.
 */
class MessagePresenter extends BasePresenter{
    
}
