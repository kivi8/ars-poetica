<?php

namespace App\Presenters;

use Nette,
	App\Model;


/**
 * MediaArchive presenter.
 */
class MediaArchivePresenter extends BasePresenter{
    
}
