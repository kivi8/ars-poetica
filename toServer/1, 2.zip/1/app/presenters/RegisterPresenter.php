<?php

namespace App\Presenters;

use Nette,
	App\Model;


/**
 * Register presenter.
 */
class RegisterPresenter extends BasePresenter{
    
    public function renderDefault(){
        
    }
}
