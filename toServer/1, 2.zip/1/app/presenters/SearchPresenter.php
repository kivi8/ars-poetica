<?php

namespace App\Presenters;

use Nette,
        App\Model;

/*
 * Search presenter
 */

class SearchPresenter extends BasePresenter{
    
    
    
}
