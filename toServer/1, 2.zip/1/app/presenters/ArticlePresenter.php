<?php

namespace App\Presenters;

use Nette,
	App\Model;


/**
 * Article presenter.
 */
class ArticlePresenter extends BasePresenter{
     
}
